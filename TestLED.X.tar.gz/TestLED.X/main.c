/*
 * File:   main.c
 * Author: mark david harrington
 *
 * Created on 10 October 2020, 13:37
 */


#include <xc.h>

#define _XTAL_FREQ 4000000

#define LED GPIObits.GP5



/* Configuration bits */
#ifdef _PIC12F675_H_
#pragma config CP = OFF, MCLRE = ON, FOSC = INTRCIO, WDTE = OFF, BOREN =OFF
#endif

/* Configuration bits */
#ifdef _PIC12F683_H_
#pragma config CP = OFF, MCLRE = ON, FOSC = INTOSCIO, WDTE = OFF, BOREN =OFF
#endif

void InitPic (void);

void main(void)
{
    
    /* PICMicro initialization */
    InitPic();

    /* Never ending cycle...*/
    while(1)
    {
        LED^=1;             /* LED alternate ON and OFF */
        __delay_ms(1000);    /* delay macro (200ms) */
    }

}

void InitPic (void)
{
/* I/O port configuration */
    GPIO  =  0x00; // clear port down

#ifdef _PIC12F675_H_
    CMCON =  0x07;      /* Disable comparators */
#endif
    
    
    ANSEL =  0x00;      /* Disable A/D module */
    TRISIO = 0x00;      /* All output is set as OUTPUT */
    WPU = 0;            /* Disable internal pull-ups */
    OPTION_REG = 0x80;  /* Disable internal pull-ups */
}

